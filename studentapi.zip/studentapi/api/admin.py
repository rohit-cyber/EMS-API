from django.conf.urls import url
from django.contrib import admin
from .models import Student, Guardian
from django.utils.html import format_html
from django.urls import reverse

# Register your models here.

class GuardianInlineAdmin(admin.TabularInline):
    model = Guardian

class StudentAdmin(admin.ModelAdmin):
    model = Student
    list_display = ['id','first_name','email', 'last_name', 'standard', 'evaluation', 'city', 'country', 'active', 'joined_on']
    inlines = [GuardianInlineAdmin]


   

class GuardianAdmin(admin.ModelAdmin):
    model = Guardian
    list_display = ['id','first_name', 'last_name', 'student', 'relation', 'address', 'mobile_number']


admin.site.register(Student, StudentAdmin)
admin.site.register(Guardian, GuardianAdmin)
