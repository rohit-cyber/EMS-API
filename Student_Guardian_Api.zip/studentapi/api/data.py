{
        "id": 2,
        "first_name": "rahul",
        "last_name": "kumar",
        "guardians": [
            {
                "id": 1,
                "first_name": "rahul father",
                "last_name": "kumar",
                "student": 2,
                "relation": "Father",
                "address": "rahul  father address",
                "mobile_number": 898787111
            }
        ],
        "standard": "Three",
        "evaluation": "Pass",
        "city": "Goa",
        "country": "India",
        "active": true,
        "joined_on": "2021-04-25"
    }